# Klara OS — Strategic Specs (Pre-Implementation)

These three documents define the core models **before** implementation. The rest of the system is plumbing that connects them.

| Spec | Purpose |
|------|--------|
| **[01 — Conversational Agent Architecture](01-conversational-agent-architecture.md)** | LangGraph-style workflow: nodes (INTAKE → RISK → ELIGIBILITY → RAG → ROUTING → RESPONSE), edges, and emergency override. |
| **[02 — NavigationContext Schema](02-navigation-context-schema.md)** | Universal session object: one JSON schema for intake, risk, eligibility, RAG context, routing result, and response. Every component reads/writes this. |
| **[03 — Optimization Model](03-optimization-model-gurobi-routing.md)** | Gurobi (MIP) formulation for care pathway routing: decision variables, constraints, objective (minimize inappropriateness + wait + capacity pressure). |

**Order of use:** Define NavigationContext first (02); then design the agent graph (01) so each node consumes and produces fields of that context; finally plug the optimizer (03) into the ROUTING_OPT node with parameters from context and capacity data.
